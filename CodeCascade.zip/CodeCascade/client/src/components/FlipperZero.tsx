import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

interface FlipperZeroProps {
  onClose: () => void;
}

type MenuOption = {
  id: string;
  label: string;
  icon: string;
  action?: () => void;
};

const mainMenu: MenuOption[] = [
  { id: "sub_ghz", label: "Sub-GHz", icon: "📡" },
  { id: "rfid", label: "125 kHz RFID", icon: "🏷️" },
  { id: "nfc", label: "NFC", icon: "💳" },
  { id: "infrared", label: "Infrared", icon: "🔴" },
  { id: "gpio", label: "GPIO", icon: "🔌" },
  { id: "ibutton", label: "iButton", icon: "🔑" },
  { id: "badusb", label: "Bad USB", icon: "💾" },
  { id: "u2f", label: "U2F", icon: "🔐" },
  { id: "settings", label: "Settings", icon: "⚙️" },
];

const DISPLAY_WIDTH = 128;
const DISPLAY_HEIGHT = 64;

export default function FlipperZero({ onClose }: FlipperZeroProps) {
  const [currentMenu, setCurrentMenu] = useState<"main" | "tool">("main");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [selectedTool, setSelectedTool] = useState<string>("");
  const [dolphinMood, setDolphinMood] = useState<"happy" | "neutral" | "excited">("happy");
  const [screenContent, setScreenContent] = useState<string[]>([]);

  // Dolphin animation
  useEffect(() => {
    const interval = setInterval(() => {
      setDolphinMood(prev => {
        const moods: ("happy" | "neutral" | "excited")[] = ["happy", "neutral", "excited"];
        const currentIndex = moods.indexOf(prev);
        return moods[(currentIndex + 1) % moods.length];
      });
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleUp = () => {
    if (currentMenu === "main") {
      setSelectedIndex(prev => (prev - 1 + mainMenu.length) % mainMenu.length);
    }
  };

  const handleDown = () => {
    if (currentMenu === "main") {
      setSelectedIndex(prev => (prev + 1) % mainMenu.length);
    }
  };

  const handleOk = () => {
    if (currentMenu === "main") {
      const selected = mainMenu[selectedIndex];
      setSelectedTool(selected.id);
      setCurrentMenu("tool");
      simulateTool(selected.id);
    }
  };

  const handleBack = () => {
    if (currentMenu === "tool") {
      setCurrentMenu("main");
      setScreenContent([]);
    } else {
      onClose();
    }
  };

  const simulateTool = (toolId: string) => {
    switch (toolId) {
      case "sub_ghz":
        setScreenContent([
          "Sub-GHz Analyzer",
          "━━━━━━━━━━━━━━━",
          "Frequency: 433.92 MHz",
          "Signal: -72 dBm",
          "Modulation: ASK/OOK",
          "",
          "Press OK to capture"
        ]);
        break;
      case "rfid":
        setScreenContent([
          "125 kHz RFID",
          "━━━━━━━━━━━━━━━",
          "Reading...",
          "",
          "EM4100: 0x1A2B3C4D5E",
          "Facility: 42",
          "Card: 12345"
        ]);
        break;
      case "nfc":
        setScreenContent([
          "NFC Reader",
          "━━━━━━━━━━━━━━━",
          "Place card on back",
          "",
          "Type: Mifare Classic",
          "UID: 04:A1:B2:C3",
          "Memory: 1K"
        ]);
        break;
      case "infrared":
        setScreenContent([
          "Infrared",
          "━━━━━━━━━━━━━━━",
          "Learn new remote",
          "",
          "1. TV Power",
          "2. Volume Up",
          "3. Volume Down"
        ]);
        break;
      case "badusb":
        setScreenContent([
          "Bad USB",
          "━━━━━━━━━━━━━━━",
          "Scripts:",
          "",
          "1. Hello World",
          "2. Rick Roll",
          "3. Win + R"
        ]);
        break;
      default:
        setScreenContent([
          mainMenu.find(m => m.id === toolId)?.label || "",
          "━━━━━━━━━━━━━━━",
          "",
          "Feature coming soon!"
        ]);
    }
  };

  const getDolphinArt = () => {
    switch (dolphinMood) {
      case "happy":
        return [
          "     ___     ",
          "    /o o\\    ",
          "   ( > < )   ",
          "    \\___/    ",
          "  ~~|   |~~  ",
          "    |___|    "
        ];
      case "neutral":
        return [
          "     ___     ",
          "    /- -\\    ",
          "   ( - - )   ",
          "    \\___/    ",
          "  ~~|   |~~  ",
          "    |___|    "
        ];
      case "excited":
        return [
          "     ___     ",
          "    /^ ^\\    ",
          "   ( o o )   ",
          "    \\___/    ",
          "  ~~|   |~~  ",
          "    |___|    "
        ];
    }
  };

  const renderMainMenu = () => {
    const visibleItems = 4;
    const startIndex = Math.max(0, selectedIndex - Math.floor(visibleItems / 2));
    const endIndex = Math.min(mainMenu.length, startIndex + visibleItems);
    
    return (
      <div className="h-full flex">
        {/* Left side - Dolphin */}
        <div className="w-1/2 flex flex-col items-center justify-center text-xs leading-none">
          {getDolphinArt().map((line, i) => (
            <div key={i} className="font-mono">{line}</div>
          ))}
        </div>
        
        {/* Right side - Menu */}
        <div className="w-1/2 flex flex-col justify-center text-xs">
          {mainMenu.slice(startIndex, endIndex).map((item, index) => {
            const actualIndex = startIndex + index;
            return (
              <div
                key={item.id}
                className={`px-1 py-0.5 ${
                  actualIndex === selectedIndex ? "bg-orange-400 text-black" : ""
                }`}
              >
                {item.icon} {item.label}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const renderToolScreen = () => {
    return (
      <div className="h-full p-2 text-xs font-mono leading-tight">
        {screenContent.map((line, i) => (
          <div key={i}>{line}</div>
        ))}
      </div>
    );
  };

  return (
    <div className="h-screen w-full flex items-center justify-center bg-gray-900">
      <div className="relative">
        {/* Flipper Zero Device Body */}
        <div className="bg-gray-800 rounded-3xl p-8 shadow-2xl">
          {/* Screen */}
          <div 
            className="bg-orange-100 rounded-lg mb-6 relative overflow-hidden"
            style={{
              width: `${DISPLAY_WIDTH * 3}px`,
              height: `${DISPLAY_HEIGHT * 3}px`,
              boxShadow: "inset 0 0 20px rgba(251, 146, 60, 0.3)"
            }}
          >
            <div className="absolute inset-0 bg-orange-50 p-2">
              {currentMenu === "main" ? renderMainMenu() : renderToolScreen()}
            </div>
          </div>

          {/* Control Buttons */}
          <div className="grid grid-cols-3 gap-2 mb-4">
            <div></div>
            <Button
              variant="secondary"
              className="bg-gray-700 hover:bg-gray-600 text-white rounded-full h-12 w-12"
              onClick={handleUp}
            >
              ▲
            </Button>
            <div></div>
            
            <Button
              variant="secondary"
              className="bg-gray-700 hover:bg-gray-600 text-white rounded-full h-12 w-12"
              onClick={() => {}}
            >
              ◄
            </Button>
            <Button
              variant="secondary"
              className="bg-orange-500 hover:bg-orange-400 text-white rounded-full h-12 w-12"
              onClick={handleOk}
            >
              OK
            </Button>
            <Button
              variant="secondary"
              className="bg-gray-700 hover:bg-gray-600 text-white rounded-full h-12 w-12"
              onClick={() => {}}
            >
              ►
            </Button>
            
            <div></div>
            <Button
              variant="secondary"
              className="bg-gray-700 hover:bg-gray-600 text-white rounded-full h-12 w-12"
              onClick={handleDown}
            >
              ▼
            </Button>
            <div></div>
          </div>

          {/* Back Button */}
          <div className="flex justify-center">
            <Button
              variant="secondary"
              className="bg-red-600 hover:bg-red-500 text-white px-6"
              onClick={handleBack}
            >
              ← BACK
            </Button>
          </div>

          {/* Device Label */}
          <div className="text-center mt-4 text-gray-400 text-sm">
            Flipper Zero Emulator
          </div>
        </div>

        {/* Exit button */}
        <Button
          variant="ghost"
          className="absolute top-4 right-4 text-gray-400 hover:text-white"
          onClick={onClose}
        >
          ✕ Exit Flipper Mode
        </Button>
      </div>
    </div>
  );
}