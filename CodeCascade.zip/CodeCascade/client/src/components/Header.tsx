import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import type { Project } from "@shared/schema";

interface HeaderProps {
  project?: Project;
  onModeSwitch: () => void;
  currentMode: "ide" | "flipper";
}

export default function Header({ project, onModeSwitch, currentMode }: HeaderProps) {
  return (
    <header className="replit-bg-sidebar border-b replit-border h-12 flex items-center px-4 justify-between">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <i className="fas fa-code replit-blue text-xl"></i>
          <span className="font-semibold text-lg replit-text">Replit Clone</span>
        </div>
        <div className="flex items-center space-x-2 text-sm">
          <Badge variant="secondary" className="replit-bg-surface replit-text-muted">
            Free Plan
          </Badge>
          <span className="replit-green">• Unlimited</span>
        </div>
      </div>
      
      <div className="flex items-center space-x-3">
        <Button
          onClick={onModeSwitch}
          variant="ghost"
          size="sm"
          className="px-3 py-1 hover:bg-opacity-20 hover:bg-white flex items-center space-x-2"
        >
          {currentMode === "ide" ? (
            <>
              <span className="text-orange-400">🐬</span>
              <span className="replit-text-muted text-sm">Flipper Zero</span>
            </>
          ) : (
            <>
              <i className="fas fa-code replit-blue"></i>
              <span className="replit-text-muted text-sm">IDE Mode</span>
            </>
          )}
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="p-2 hover:bg-opacity-20 hover:bg-white"
        >
          <i className="fas fa-share-alt replit-text-muted"></i>
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="p-2 hover:bg-opacity-20 hover:bg-white"
        >
          <i className="fas fa-cog replit-text-muted"></i>
        </Button>
        <Avatar className="w-8 h-8">
          <AvatarFallback style={{ backgroundColor: 'var(--replit-purple)' }}>
            U
          </AvatarFallback>
        </Avatar>
      </div>
    </header>
  );
}
