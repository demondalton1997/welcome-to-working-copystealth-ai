import { Button } from "@/components/ui/button";
import MonacoEditor from "./MonacoEditor";
import type { File } from "@shared/schema";

interface MainEditorProps {
  files: File[];
  activeFile?: File;
  openTabs: File[];
  onFileOpen: (file: File) => void;
  onTabClose: (fileId: number) => void;
  onTabChange: (fileId: number) => void;
}

export default function MainEditor({
  files,
  activeFile,
  openTabs,
  onFileOpen,
  onTabClose,
  onTabChange,
}: MainEditorProps) {
  const getFileIcon = (file: File) => {
    const extension = file.name.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'js':
      case 'jsx':
        return "fas fa-file-code replit-blue";
      case 'json':
        return "fas fa-file-code replit-green";
      case 'md':
        return "fas fa-file-alt replit-text-muted";
      case 'py':
        return "fas fa-file-code replit-green";
      case 'html':
        return "fas fa-file-code replit-red";
      case 'css':
        return "fas fa-file-code replit-blue";
      default:
        return "fas fa-file replit-text-muted";
    }
  };

  const executeCode = async () => {
    if (!activeFile) return;
    
    try {
      const response = await fetch('/api/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: activeFile.content,
          language: 'javascript'
        })
      });
      
      const result = await response.json();
      console.log('Execution result:', result);
    } catch (error) {
      console.error('Execution error:', error);
    }
  };

  return (
    <div className="flex-1 flex flex-col">
      {/* Editor Tabs */}
      <div className="replit-bg-sidebar border-b replit-border flex items-center overflow-x-auto">
        <div className="flex">
          {openTabs.map((tab) => (
            <div
              key={tab.id}
              className={`flex items-center px-4 py-2 border-r replit-border cursor-pointer ${
                activeFile?.id === tab.id
                  ? 'tab-active replit-bg-dark'
                  : 'hover:bg-opacity-20 hover:bg-white'
              }`}
              onClick={() => onTabChange(tab.id)}
            >
              <i className={`${getFileIcon(tab)} mr-2 text-sm`}></i>
              <span className="text-sm">{tab.name}</span>
              <Button
                variant="ghost"
                size="sm"
                className="ml-2 p-1 hover:bg-opacity-20 hover:bg-white rounded-full"
                onClick={(e) => {
                  e.stopPropagation();
                  onTabClose(tab.id);
                }}
              >
                <i className="fas fa-times text-xs"></i>
              </Button>
            </div>
          ))}
        </div>
        
        <div className="flex-1"></div>
        
        <div className="flex items-center space-x-2 px-4">
          <Button
            variant="ghost"
            size="sm"
            className="p-1 hover:bg-opacity-20 hover:bg-white"
            onClick={executeCode}
          >
            <i className="fas fa-play replit-green"></i>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="p-1 hover:bg-opacity-20 hover:bg-white"
          >
            <i className="fas fa-save replit-blue"></i>
          </Button>
        </div>
      </div>

      {/* Monaco Editor Container */}
      <div className="flex-1 relative">
        {activeFile ? (
          <MonacoEditor file={activeFile} />
        ) : (
          <div className="h-full flex items-center justify-center replit-bg-dark">
            <div className="text-center">
              <i className="fas fa-file-code text-4xl replit-text-muted mb-4"></i>
              <p className="replit-text-muted">Select a file to start editing</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
