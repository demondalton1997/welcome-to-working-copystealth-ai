import { useEffect, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useWebSocket } from "@/lib/websocket";
import type { File } from "@shared/schema";

interface MonacoEditorProps {
  file: File;
}

export default function MonacoEditor({ file }: MonacoEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const { sendMessage } = useWebSocket();

  const updateFileMutation = useMutation({
    mutationFn: async (content: string) => {
      return apiRequest("PUT", `/api/files/${file.id}`, { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${file.projectId}/files`] });
    },
  });

  const handleContentChange = (content: string) => {
    updateFileMutation.mutate(content);
    sendMessage({
      type: 'file_change',
      fileId: file.id,
      content
    });
  };

  // For now, we'll create a simple textarea-based editor
  // In a real implementation, you would integrate Monaco Editor here
  return (
    <div className="h-full replit-bg-dark">
      <div className="h-full p-4">
        <textarea
          className="w-full h-full bg-transparent replit-text font-mono text-sm leading-6 resize-none outline-none"
          value={file.content || ""}
          onChange={(e) => handleContentChange(e.target.value)}
          placeholder="Start typing your code..."
          style={{ fontFamily: 'Monaco, Consolas, "Courier New", monospace' }}
        />
      </div>
    </div>
  );
}
