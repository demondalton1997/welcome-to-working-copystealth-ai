import { Button } from "@/components/ui/button";
import Chat from "./Chat";

interface RightPanelProps {
  projectId: number;
  activeTab: 'chat' | 'collaborate';
  onTabChange: (tab: 'chat' | 'collaborate') => void;
}

export default function RightPanel({ projectId, activeTab, onTabChange }: RightPanelProps) {
  return (
    <div className="w-80 replit-bg-sidebar border-l replit-border flex flex-col">
      {/* Panel Tabs */}
      <div className="flex border-b replit-border">
        <Button
          variant="ghost"
          className={`flex-1 py-2 px-4 text-sm font-medium ${
            activeTab === 'chat'
              ? 'replit-bg-dark replit-blue border-b-2 border-blue-500'
              : 'hover:bg-opacity-20 hover:bg-white replit-text-muted'
          }`}
          onClick={() => onTabChange('chat')}
        >
          <i className="fas fa-comments mr-2"></i>Chat
        </Button>
        <Button
          variant="ghost"
          className={`flex-1 py-2 px-4 text-sm font-medium ${
            activeTab === 'collaborate'
              ? 'replit-bg-dark replit-blue border-b-2 border-blue-500'
              : 'hover:bg-opacity-20 hover:bg-white replit-text-muted'
          }`}
          onClick={() => onTabChange('collaborate')}
        >
          <i className="fas fa-users mr-2"></i>Collaborate
        </Button>
      </div>

      {/* Panel Content */}
      <div className="flex-1 flex flex-col">
        {activeTab === 'chat' ? (
          <Chat projectId={projectId} />
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <i className="fas fa-users text-4xl replit-text-muted mb-4"></i>
              <p className="replit-text-muted">Collaboration features coming soon</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
