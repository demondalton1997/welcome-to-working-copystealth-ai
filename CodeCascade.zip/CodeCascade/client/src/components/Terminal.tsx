import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";

interface TerminalProps {
  height: number;
  onHeightChange: (height: number) => void;
  onToggle: () => void;
}

export default function Terminal({ height, onHeightChange, onToggle }: TerminalProps) {
  const [activeTab, setActiveTab] = useState<'console' | 'shell' | 'logs'>('console');
  const [command, setCommand] = useState("");
  const [output, setOutput] = useState<string[]>([
    "Welcome to Replit Clone Terminal",
    "~/my-awesome-project $ npm install express",
    "✓ express@4.18.2 installed",
    "~/my-awesome-project $ node index.js",
    "Server running on port 3000",
  ]);
  const inputRef = useRef<HTMLInputElement>(null);
  const outputRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [output]);

  const executeCommand = async () => {
    if (!command.trim()) return;

    const newOutput = [...output, `~/my-awesome-project $ ${command}`];
    
    // Simple command simulation
    if (command === "ls") {
      newOutput.push("index.js  package.json  README.md");
    } else if (command === "pwd") {
      newOutput.push("/home/user/my-awesome-project");
    } else if (command.startsWith("echo ")) {
      newOutput.push(command.substring(5));
    } else if (command === "clear") {
      setOutput([]);
      setCommand("");
      return;
    } else {
      newOutput.push(`bash: ${command}: command not found`);
    }

    setOutput(newOutput);
    setCommand("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      executeCommand();
    }
  };

  const clearTerminal = () => {
    setOutput([]);
  };

  return (
    <div className="replit-bg-dark border-t replit-border flex flex-col" style={{ height }}>
      <div className="flex items-center justify-between px-4 py-2 replit-bg-sidebar border-b replit-border">
        <div className="flex items-center space-x-4">
          <div className="flex space-x-2">
            {(['console', 'shell', 'logs'] as const).map((tab) => (
              <Button
                key={tab}
                variant="ghost"
                className={`text-sm font-medium ${
                  activeTab === tab
                    ? 'replit-blue border-b border-blue-500 pb-1'
                    : 'replit-text-muted hover:text-white'
                }`}
                onClick={() => setActiveTab(tab)}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </Button>
            ))}
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            className="p-1 hover:bg-opacity-20 hover:bg-white"
            onClick={clearTerminal}
          >
            <i className="fas fa-trash replit-text-muted"></i>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="p-1 hover:bg-opacity-20 hover:bg-white"
            onClick={onToggle}
          >
            <i className="fas fa-minus replit-text-muted"></i>
          </Button>
        </div>
      </div>
      
      <div className="flex-1 overflow-hidden">
        <div
          ref={outputRef}
          className="h-full p-4 overflow-y-auto terminal-output text-sm replit-text"
        >
          {output.map((line, index) => (
            <div key={index} className="mb-1">
              {line}
            </div>
          ))}
          
          <div className="flex items-center">
            <span className="replit-text-muted">~/my-awesome-project $ </span>
            <input
              ref={inputRef}
              type="text"
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              onKeyPress={handleKeyPress}
              className="flex-1 bg-transparent outline-none replit-text ml-1"
              style={{ fontFamily: 'Monaco, Consolas, "Courier New", monospace' }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
