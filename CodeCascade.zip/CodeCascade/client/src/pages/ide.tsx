import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import MainEditor from "@/components/MainEditor";
import RightPanel from "@/components/RightPanel";
import Terminal from "@/components/Terminal";
import FlipperZero from "@/components/FlipperZero";
import { WebSocketProvider } from "@/lib/websocket";
import type { Project, File } from "@shared/schema";

export default function IDE() {
  const { id } = useParams<{ id: string }>();
  const projectId = id ? parseInt(id) : 1;
  const [activeFileId, setActiveFileId] = useState<number | null>(null);
  const [openTabs, setOpenTabs] = useState<File[]>([]);
  const [rightPanelTab, setRightPanelTab] = useState<'chat' | 'collaborate'>('chat');
  const [terminalHeight, setTerminalHeight] = useState(256);
  const [isTerminalVisible, setIsTerminalVisible] = useState(true);
  const [currentMode, setCurrentMode] = useState<"ide" | "flipper">("ide");

  const { data: project, isLoading: projectLoading } = useQuery<Project>({
    queryKey: [`/api/projects/${projectId}`],
  });

  const { data: files = [], isLoading: filesLoading } = useQuery<File[]>({
    queryKey: [`/api/projects/${projectId}/files`],
  });

  const activeFile = files.find(file => file.id === activeFileId);

  useEffect(() => {
    if (files.length > 0 && !activeFileId) {
      const firstFile = files.find(file => !file.isDirectory);
      if (firstFile) {
        setActiveFileId(firstFile.id);
        setOpenTabs([firstFile]);
      }
    }
  }, [files, activeFileId]);

  const openFile = (file: File) => {
    if (file.isDirectory) return;
    
    setActiveFileId(file.id);
    
    const existingTab = openTabs.find(tab => tab.id === file.id);
    if (!existingTab) {
      setOpenTabs(prev => [...prev, file]);
    }
  };

  const closeTab = (fileId: number) => {
    setOpenTabs(prev => {
      const newTabs = prev.filter(tab => tab.id !== fileId);
      
      if (activeFileId === fileId) {
        const currentIndex = prev.findIndex(tab => tab.id === fileId);
        if (newTabs.length > 0) {
          const newActiveIndex = currentIndex > 0 ? currentIndex - 1 : 0;
          setActiveFileId(newTabs[newActiveIndex].id);
        } else {
          setActiveFileId(null);
        }
      }
      
      return newTabs;
    });
  };

  const toggleTerminal = () => {
    setIsTerminalVisible(!isTerminalVisible);
  };

  const handleModeSwitch = () => {
    setCurrentMode(prev => prev === "ide" ? "flipper" : "ide");
  };

  if (projectLoading || filesLoading) {
    return (
      <div className="h-screen flex items-center justify-center replit-bg-dark">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="replit-text-muted">Loading project...</p>
        </div>
      </div>
    );
  }

  // Show Flipper Zero mode
  if (currentMode === "flipper") {
    return <FlipperZero onClose={() => setCurrentMode("ide")} />;
  }

  // Show IDE mode
  return (
    <WebSocketProvider projectId={projectId} userId={1}>
      <div className="h-screen flex flex-col replit-bg-dark overflow-hidden">
        <Header 
          project={project} 
          onModeSwitch={handleModeSwitch}
          currentMode={currentMode}
        />
        
        <div className="flex flex-1 overflow-hidden">
          <Sidebar 
            project={project}
            files={files}
            onFileOpen={openFile}
          />
          
          <div className="flex-1 flex flex-col">
            <MainEditor
              files={files}
              activeFile={activeFile}
              openTabs={openTabs}
              onFileOpen={openFile}
              onTabClose={closeTab}
              onTabChange={setActiveFileId}
            />
            
            {isTerminalVisible && (
              <Terminal
                height={terminalHeight}
                onHeightChange={setTerminalHeight}
                onToggle={toggleTerminal}
              />
            )}
          </div>
          
          <RightPanel
            projectId={projectId}
            activeTab={rightPanelTab}
            onTabChange={setRightPanelTab}
          />
        </div>
        
        {/* Status Bar */}
        <div className="replit-bg-sidebar border-t replit-border px-4 py-1 flex items-center justify-between text-xs">
          <div className="flex items-center space-x-4">
            <span className="replit-green">● Connected</span>
            <span className="replit-text-muted">{project?.language || 'JavaScript'}</span>
            <span className="replit-text-muted">UTF-8</span>
          </div>
          <div className="flex items-center space-x-4">
            <span className="replit-text-muted">Ln 1, Col 1</span>
            <span className="replit-text-muted">Spaces: 2</span>
            <button 
              className="hover:text-white replit-text-muted"
              onClick={toggleTerminal}
            >
              <i className="fas fa-expand-arrows-alt"></i>
            </button>
          </div>
        </div>
      </div>
    </WebSocketProvider>
  );
}
