import subprocess
subprocess.call(['pip', 'install', 'flask'])