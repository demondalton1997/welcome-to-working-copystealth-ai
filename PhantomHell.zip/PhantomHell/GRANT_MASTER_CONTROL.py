🚀 INITIATING GRANT_MASTER_CONTROL SEQUENCE

📂 Scanning: /private/var/mobile/.../PhantomFIREMAX
✅ Granted 0777 to .../PhantomFIREMAX/core.py
✅ Granted 0777 to .../PhantomFIREMAX/OTA/auto_update.py
...

📂 Scanning: /private/var/mobile/.../PhantomIntel
✅ Granted 0777 to .../PhantomIntel/log_manager.py
✅ Granted 0777 to .../PhantomIntel/dashboard/hook.js
...

📂 Scanning: /private/var/mobile/.../PhantomNet
✅ Granted 0777 to .../PhantomNet/net_watch.py
✅ Granted 0777 to .../PhantomNet/ble_scan.js

🧠 Injecting PhantomAI Autowatcher...
👁️ PhantomAI linked to all modules.

🔄 Syncing with PhantomIntel Dashboard...
📊 Logs injected and reflected in live panel.

✅ GRANT_MASTER_CONTROL.py completed.
