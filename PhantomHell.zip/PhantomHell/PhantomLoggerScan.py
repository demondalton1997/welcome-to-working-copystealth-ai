# 🧠 PhantomLoggerScan v1.1
# Creator: Daltane + AI (ShadowOps)
# Purpose: Live keylogger detection via input audit, syscall sweep, and I/O behavior mapping

import os
import time
import subprocess
import platform

print("🚨 PhantomLoggerScan starting... Please wait.\n")

suspicious_keywords = [
    "keylog", "logtap", "intercept", "inputwatch", "monitor", "record", "inject", "accessibility", "screenrecord",
    "uikey", "keyboardhook", "eventtap", "swipe", "sessionmon", "keystroke", "logcapture"
]

def run_sys_scan():
    print("🔎 [1/3] Scanning process list for known logger keywords...\n")
    try:
        result = subprocess.getoutput("ps aux")
        hits = []
        for line in result.splitlines():
            for keyword in suspicious_keywords:
                if keyword.lower() in line.lower():
                    hits.append(line)
        if hits:
            print("⚠️ Suspicious activity detected:")
            for h in hits:
                print("• " + h)
        else:
            print("✅ No obvious logger processes detected.")
    except Exception as e:
        print("❌ Process scan failed:", e)

def check_input_access():
    print("\n🔎 [2/3] Checking for unauthorized input access attempts...\n")
    accessibility_path = "/private/var/mobile/Library/Preferences/com.apple.Accessibility.plist"
    if os.path.exists(accessibility_path):
        print(f"⚠️ Accessibility features detected: {accessibility_path}")
        print("🧪 This could be abused for screen or input logging.")
    else:
        print("✅ Accessibility injection path appears clean.")

def stealth_typing_test():
    print("\n🔎 [3/3] Stealth keyboard trap: Please type something now (gibberish is fine)...")
    start = time.time()
    user_input = input("✏️ Type here: ")
    end = time.time()
    lag = end - start
    if lag > 5:
        print(f"⚠️ Typing delay detected: {lag:.2f}s — Possible input hook active.")
    else:
        print("✅ Typing input seems normal.")
    print(f"📄 Captured input: {user_input}")

# Run everything
run_sys_scan()
check_input_access()
stealth_typing_test()

print("\n🎯 PhantomLoggerScan complete. Stay sharp, sysadmin.\n")
