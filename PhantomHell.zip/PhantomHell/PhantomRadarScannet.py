
# File: PhantomRadarScanner.py
import asyncio, json, os
from datetime import datetime
from bleak import BleakScanner

log_file = "/private/var/mobile/Library/Mobile Documents/iCloud~xyz~Pyto/Documents/phantom/devices.json"

async def scan():
    devices = await BleakScanner.discover()
    output = []
    for d in devices:
        output.append({
            "name": d.name or "Unknown",
            "mac": d.address,
            "rssi": d.rssi,
            "last_seen": datetime.now().isoformat()
        })

    with open(log_file, "w") as f:
        json.dump(output, f, indent=2)

asyncio.run(scan())