
# 🔐 PhantomTrapX v2.0 (Daltane-Authorized Deployment)
# Made to expose stealth keyloggers and screen monitoring agents via trap bait

import os
import time
import subprocess
import random
from datetime import datetime

trap_log_path = os.path.expanduser("~/Documents/PhantomTrapX_Logs")
os.makedirs(trap_log_path, exist_ok=True)
os.makedirs(trap_log_path, exist_ok=True)

def log_event(event: str):
    with open(os.path.join(trap_log_path, "traplog.txt"), "a") as f:
        f.write(f"[{datetime.now()}] {event}\n")

print("🎯 Deploying PhantomTrapX: Live keylog bait + syscall monitor\n")

# Bait Setup
honeypot_input = [
    "MyRealPass123!", "BankPassword!", "SecretToken", "MasterLogin$",
    "Hunter2", "D@ltane97#", "PhantomRoot99"
]

# Module 1: Input Lag Trap
print("💡 MODULE 1: Input Trap Triggering")
for bait in honeypot_input:
    print(f"Type this fake password bait: {bait}")
    start = time.time()
    typed = input("✏️ Type here: ")
    duration = time.time() - start
    if bait != typed:
        print(f"⚠️ Input mismatch! You typed: {typed}")
        log_event(f"Mismatch Trap Triggered! Expected: {bait}, Got: {typed}")
    if duration > 4:
        print(f"⚠️ Lag Detected ({duration:.2f}s) — Possible Hook!")
        log_event(f"Lag Detected: {duration:.2f}s on input '{bait}'")
    else:
        print("✅ Input clean.")
    time.sleep(1)

# Module 2: Background Process Logger
print("\n💡 MODULE 2: Stealth Process Sweep")
suspicious = []
try:
    output = subprocess.getoutput("ps aux")
    redflags = ["keylog", "intercept", "logger", "record", "accessibility", "input", "event", "spy", "session"]
    for line in output.splitlines():
        if any(term in line.lower() for term in redflags):
            suspicious.append(line)
except Exception as e:
    print("❌ Process check failed:", e)

if suspicious:
    print("⚠️ Suspicious Processes Found:")
    for proc in suspicious:
        print("•", proc)
        log_event(f"Suspicious Process: {proc}")
else:
    print("✅ No logger processes detected.")

# Module 3: Filewatch Trap
print("\n💡 MODULE 3: File Access Trap")
bait_file = os.path.join(trap_log_path, "login.txt")
with open(bait_file, "w") as f:
    f.write("This is fake login data for bait purposes only.\n")

time.sleep(1.5)
stat = os.stat(bait_file)
if stat.st_atime != stat.st_ctime:
    print("⚠️ File accessed unexpectedly!")
    log_event("Bait file accessed — potential logger snooping.")
else:
    print("✅ Bait file clean.")

# Wrap Up
print("\n🎯 PhantomTrapX complete. Log saved at:", trap_log_path)
print("👁️ Stay paranoid. You’re probably right.\n")