# server.py - run this in Pyto or any Python env
from flask import Flask, request, jsonify
from datetime import datetime

app = Flask(__name__)
messages = []

@app.route('/send', methods=['POST'])
def send_message():
    data = request.json
    content = data.get('content', '')
    timestamp = datetime.utcnow().isoformat()
    messages.append({'content': content, 'timestamp': timestamp})
    print(f"[+] Received message: {content} at {timestamp}")
    return jsonify({'status': 'success', 'message_count': len(messages)})

@app.route('/messages', methods=['GET'])
def get_messages():
    return jsonify(messages)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
