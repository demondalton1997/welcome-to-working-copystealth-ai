#chmod 0777 my_script.sh 

 # Grants full permissions to everyone.

