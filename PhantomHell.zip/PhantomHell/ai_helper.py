# ai_helper.py
def get_code_suggestion(code_snippet):
    # Dummy AI logic placeholder
    return f"Suggestion for: {code_snippet}\nTry using a list comprehension instead."
