import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { apiRequest } from "@/lib/queryClient";
import { useWebSocket } from "@/lib/websocket";
import type { ChatMessage } from "@shared/schema";

interface ChatProps {
  projectId: number;
}

export default function Chat({ projectId }: ChatProps) {
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const { sendMessage: sendWebSocketMessage } = useWebSocket();

  const { data: messages = [] } = useQuery<ChatMessage[]>({
    queryKey: [`/api/projects/${projectId}/chat`],
    refetchInterval: 5000, // Refetch every 5 seconds
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      return apiRequest("POST", "/api/chat", {
        content,
        userId: 1,
        projectId,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/chat`] });
      setMessage("");
    },
  });

  const handleSendMessage = () => {
    if (message.trim()) {
      sendMessageMutation.mutate(message);
      sendWebSocketMessage({
        type: 'chat_message',
        message: message,
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <>
      {/* Chat Header */}
      <div className="p-3 border-b replit-border">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium replit-text">Project Chat</span>
          <Badge variant="secondary" className="text-xs replit-green">
            • Unlimited
          </Badge>
        </div>
        <div className="text-xs replit-text-muted mt-1">2 participants online</div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {messages.map((msg) => (
          <div key={msg.id} className="flex items-start space-x-2">
            <Avatar className="w-6 h-6">
              <AvatarFallback style={{ backgroundColor: 'var(--replit-purple)' }}>
                U
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-1">
                <span className="text-sm font-medium replit-text">User</span>
                <span className="text-xs replit-text-muted">
                  {formatTime(msg.createdAt)}
                </span>
              </div>
              <div className="text-sm replit-text">{msg.content}</div>
            </div>
          </div>
        ))}

        {/* AI Assistant Message */}
        <div className="replit-bg-surface rounded-lg p-3 text-sm">
          <div className="flex items-center space-x-2 mb-2">
            <i className="fas fa-robot replit-green"></i>
            <span className="font-medium replit-text">AI Assistant</span>
          </div>
          <div className="replit-text">
            I can help you write code, debug issues, and explain concepts. Just ask me anything!
          </div>
        </div>

        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="p-3 border-t replit-border">
        <div className="flex space-x-2">
          <Input
            type="text"
            placeholder="Type a message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1 replit-bg-surface border replit-border replit-text text-sm focus:border-blue-500"
          />
          <Button
            onClick={handleSendMessage}
            disabled={!message.trim() || sendMessageMutation.isPending}
            className="px-3 py-2 bg-blue-500 text-white hover:bg-blue-600"
          >
            <i className="fas fa-paper-plane"></i>
          </Button>
        </div>
      </div>
    </>
  );
}
