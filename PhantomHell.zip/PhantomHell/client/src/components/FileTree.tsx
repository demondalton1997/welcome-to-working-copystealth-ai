import { Button } from "@/components/ui/button";
import type { File } from "@shared/schema";

interface FileTreeProps {
  files: File[];
  onFileOpen: (file: File) => void;
}

export default function FileTree({ files, onFileOpen }: FileTreeProps) {
  const getFileIcon = (file: File) => {
    if (file.isDirectory) {
      return "fas fa-folder replit-yellow";
    }
    
    const extension = file.name.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'js':
      case 'jsx':
        return "fas fa-file-code replit-blue";
      case 'json':
        return "fas fa-file-code replit-green";
      case 'md':
        return "fas fa-file-alt replit-text-muted";
      case 'py':
        return "fas fa-file-code replit-green";
      case 'html':
        return "fas fa-file-code replit-red";
      case 'css':
        return "fas fa-file-code replit-blue";
      default:
        return "fas fa-file replit-text-muted";
    }
  };

  const rootFiles = files.filter(file => !file.parentId);

  return (
    <div className="file-tree">
      {rootFiles.map((file) => (
        <Button
          key={file.id}
          variant="ghost"
          className="file-tree-item w-full justify-start py-1 px-2 cursor-pointer hover:bg-opacity-20 hover:bg-blue-500"
          onClick={() => onFileOpen(file)}
        >
          <i className={`${getFileIcon(file)} mr-2 text-sm`}></i>
          <span className="text-sm">{file.name}</span>
        </Button>
      ))}
    </div>
  );
}
