import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import FileTree from "./FileTree";
import type { Project, File } from "@shared/schema";

interface SidebarProps {
  project?: Project;
  files: File[];
  onFileOpen: (file: File) => void;
}

export default function Sidebar({ project, files, onFileOpen }: SidebarProps) {
  const [selectedLanguage, setSelectedLanguage] = useState(project?.language || "javascript");

  return (
    <div className="w-64 replit-bg-sidebar border-r replit-border flex flex-col">
      {/* Project Info */}
      <div className="p-4 border-b replit-border">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-semibold text-sm replit-text">
            {project?.name || "my-awesome-project"}
          </h2>
          <div className="flex space-x-1">
            <Button
              variant="ghost"
              size="sm"
              className="p-1 hover:bg-opacity-20 hover:bg-white"
            >
              <i className="fas fa-plus text-xs"></i>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="p-1 hover:bg-opacity-20 hover:bg-white"
            >
              <i className="fas fa-folder-plus text-xs"></i>
            </Button>
          </div>
        </div>
        <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
          <SelectTrigger className="w-full replit-bg-surface border replit-border replit-text text-sm">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="javascript">JavaScript (Node.js)</SelectItem>
            <SelectItem value="python">Python</SelectItem>
            <SelectItem value="html">HTML/CSS/JS</SelectItem>
            <SelectItem value="react">React</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* File Explorer */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-2">
          <div className="text-xs font-medium replit-text-muted mb-2 flex items-center justify-between">
            <span>FILES</span>
            <Button
              variant="ghost"
              size="sm"
              className="p-1 hover:text-white"
            >
              <i className="fas fa-refresh text-xs"></i>
            </Button>
          </div>
          
          <FileTree files={files} onFileOpen={onFileOpen} />
        </div>
      </div>

      {/* Tools Section */}
      <div className="border-t replit-border p-2">
        <div className="text-xs font-medium replit-text-muted mb-2">TOOLS</div>
        <div className="space-y-1">
          <Button
            variant="ghost"
            className="w-full justify-start py-1 px-2 text-sm hover:bg-opacity-20 hover:bg-white"
          >
            <i className="fas fa-database mr-2 replit-blue"></i>
            Database
          </Button>
          <Button
            variant="ghost"
            className="w-full justify-start py-1 px-2 text-sm hover:bg-opacity-20 hover:bg-white"
          >
            <i className="fas fa-cube mr-2 replit-purple"></i>
            Packages
          </Button>
          <Button
            variant="ghost"
            className="w-full justify-start py-1 px-2 text-sm hover:bg-opacity-20 hover:bg-white"
          >
            <i className="fas fa-code-branch mr-2 replit-green"></i>
            Version Control
          </Button>
        </div>
      </div>
    </div>
  );
}
