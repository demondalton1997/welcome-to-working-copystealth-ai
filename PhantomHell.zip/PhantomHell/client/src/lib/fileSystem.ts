import type { File } from "@shared/schema";

export interface FileSystemTree {
  [key: string]: File | FileSystemTree;
}

export function buildFileTree(files: File[]): FileSystemTree {
  const tree: FileSystemTree = {};
  
  // Sort files to ensure directories come before their contents
  const sortedFiles = [...files].sort((a, b) => {
    if (a.isDirectory && !b.isDirectory) return -1;
    if (!a.isDirectory && b.isDirectory) return 1;
    return a.path.localeCompare(b.path);
  });
  
  for (const file of sortedFiles) {
    const pathParts = file.path.split('/').filter(Boolean);
    let current = tree;
    
    for (let i = 0; i < pathParts.length; i++) {
      const part = pathParts[i];
      
      if (i === pathParts.length - 1) {
        // This is the file itself
        current[part] = file;
      } else {
        // This is a directory in the path
        if (!current[part]) {
          current[part] = {};
        }
        current = current[part] as FileSystemTree;
      }
    }
  }
  
  return tree;
}

export function getFileExtension(filename: string): string {
  const parts = filename.split('.');
  return parts.length > 1 ? parts[parts.length - 1].toLowerCase() : '';
}

export function getLanguageFromExtension(extension: string): string {
  const languageMap: { [key: string]: string } = {
    js: 'javascript',
    jsx: 'javascript',
    ts: 'typescript',
    tsx: 'typescript',
    py: 'python',
    html: 'html',
    css: 'css',
    scss: 'scss',
    json: 'json',
    md: 'markdown',
    sql: 'sql',
    sh: 'shell',
    bash: 'shell',
    yml: 'yaml',
    yaml: 'yaml',
  };
  
  return languageMap[extension] || 'plaintext';
}

export function createNewFile(name: string, projectId: number, parentId?: number): Omit<File, 'id' | 'createdAt' | 'updatedAt'> {
  const isDirectory = !name.includes('.');
  const parentPath = parentId ? '' : '/'; // Simplified for now
  const path = `${parentPath}${name}`;
  
  return {
    name,
    path,
    content: isDirectory ? '' : getDefaultContent(name),
    projectId,
    isDirectory,
    parentId: parentId || null,
  };
}

function getDefaultContent(filename: string): string {
  const extension = getFileExtension(filename);
  
  const templates: { [key: string]: string } = {
    js: `// ${filename}
console.log('Hello, World!');
`,
    jsx: `// ${filename}
import React from 'react';

function Component() {
  return (
    <div>
      <h1>Hello, World!</h1>
    </div>
  );
}

export default Component;
`,
    py: `# ${filename}
print("Hello, World!")
`,
    html: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Hello, World!</h1>
</body>
</html>
`,
    css: `/* ${filename} */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
}
`,
    md: `# ${filename.replace('.md', '')}

Welcome to your new markdown file!
`,
    json: `{
  "name": "${filename.replace('.json', '')}",
  "version": "1.0.0"
}
`,
  };
  
  return templates[extension] || '';
}
