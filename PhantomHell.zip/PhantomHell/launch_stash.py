#!/private/var/containers/Bundle/Application/D3A9E86E-A5DC-44F5-BDE2-F3E9B77E92FA/Pyto.app/Pyto
# EASY-INSTALL-SCRIPT: 'StaSh==0.7.5','launch_stash.py'
__requires__ = 'StaSh==0.7.5'
__import__('pkg_resources').run_script('StaSh==0.7.5', 'launch_stash.py')
