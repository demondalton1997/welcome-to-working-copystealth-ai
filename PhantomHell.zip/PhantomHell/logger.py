# logger.py
import datetime

def log_event(event):
    with open("PhantomSync/logs/log.txt", "a") as log_file:
        timestamp = datetime.datetime.now().isoformat()
        log_file.write(f"[{timestamp}] {event}\n")
