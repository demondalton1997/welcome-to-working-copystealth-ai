#!/bin/bash
echo "Launching Phantom Flask Server on port 8080..."
python3 ~/Documents/Phantom_Hell_AI_Devbox/Pyto/phantom_server.py
