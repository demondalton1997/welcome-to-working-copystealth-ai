#!/bin/bash
echo "Phantom Terminal active. Type your commands below:"
read cmd
eval $cmd
