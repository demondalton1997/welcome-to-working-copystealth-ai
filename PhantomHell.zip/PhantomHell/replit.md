# Replit IDE Clone

## Overview

This is a full-stack web application that replicates the core functionality of Replit's online IDE. The application provides real-time collaborative code editing, file management, chat functionality, and terminal emulation. It's built as a modern web application using React for the frontend and Express.js for the backend, with WebSocket support for real-time features.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with custom Replit-themed color scheme
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Real-time Communication**: WebSocket API for live collaboration features

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints with WebSocket server for real-time features
- **Development**: Vite integration for hot module replacement and development server
- **Error Handling**: Centralized error middleware with structured logging

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM
- **Connection**: Neon Database serverless PostgreSQL
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Development Storage**: In-memory storage implementation for rapid prototyping

## Key Components

### File Management System
- **File Tree**: Hierarchical file/folder structure with icons based on file types
- **File Operations**: Create, read, update, delete files and directories
- **Tab Management**: Multiple file tabs with active file tracking
- **Monaco Editor Integration**: Placeholder for full Monaco Editor implementation (currently using textarea)

### Real-time Collaboration
- **WebSocket Server**: Handles real-time file changes and chat messages
- **Multi-user Support**: User presence and collaborative editing
- **Chat System**: Project-based chat with real-time message broadcasting
- **File Synchronization**: Live file content updates across connected clients

### User Interface
- **IDE Layout**: Three-panel layout (sidebar, main editor, right panel)
- **Terminal**: Integrated terminal with command execution simulation
- **Header**: Project information and user controls
- **Responsive Design**: Mobile-friendly interface with collapsible panels

### Database Schema
- **Users**: User authentication and profile management
- **Projects**: Project metadata and ownership
- **Files**: File structure with content and hierarchy
- **Chat Messages**: Project-based messaging system
- **Collaborators**: Project sharing and permission management

## Data Flow

1. **Client Initialization**: React app loads and establishes WebSocket connection
2. **Project Loading**: Fetch project data and file structure via REST API
3. **File Operations**: CRUD operations on files trigger database updates and WebSocket broadcasts
4. **Real-time Updates**: File changes and chat messages propagated via WebSocket to all connected clients
5. **State Synchronization**: React Query manages server state caching and invalidation

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **ws**: WebSocket server implementation
- **express**: Web application framework

### UI Dependencies
- **@radix-ui/react-***: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant API
- **lucide-react**: Icon library

### Development Dependencies
- **vite**: Build tool and development server
- **tsx**: TypeScript execution for Node.js
- **esbuild**: JavaScript bundler for production builds

## Deployment Strategy

### Development Mode
- **Frontend**: Vite dev server with HMR
- **Backend**: tsx with file watching for auto-restart
- **Database**: Neon serverless PostgreSQL
- **WebSocket**: Integrated with Express server

### Production Build
- **Frontend**: Vite build to static assets in `dist/public`
- **Backend**: esbuild bundle to `dist/index.js`
- **Deployment**: Single Node.js process serving both static files and API
- **Database**: Production PostgreSQL instance via connection string

### Build Scripts
- `npm run dev`: Development mode with hot reloading
- `npm run build`: Production build for both frontend and backend
- `npm run start`: Production server execution
- `npm run db:push`: Database schema deployment

## Changelog

Changelog:
- July 01, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.