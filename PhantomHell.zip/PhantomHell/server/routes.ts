import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertProjectSchema, insertFileSchema, insertChatMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // WebSocket server for real-time features
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  const clients = new Map<WebSocket, { userId: number; projectId: number }>();
  
  wss.on('connection', (ws) => {
    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        switch (message.type) {
          case 'join':
            clients.set(ws, { userId: message.userId, projectId: message.projectId });
            break;
            
          case 'file_change':
            // Broadcast file changes to all clients in the same project
            const clientInfo = clients.get(ws);
            if (clientInfo) {
              wss.clients.forEach((client) => {
                if (client !== ws && client.readyState === WebSocket.OPEN) {
                  const otherClientInfo = clients.get(client);
                  if (otherClientInfo && otherClientInfo.projectId === clientInfo.projectId) {
                    client.send(JSON.stringify({
                      type: 'file_change',
                      fileId: message.fileId,
                      content: message.content,
                      userId: clientInfo.userId
                    }));
                  }
                }
              });
            }
            break;
            
          case 'chat_message':
            // Broadcast chat messages to all clients in the same project
            const senderInfo = clients.get(ws);
            if (senderInfo) {
              wss.clients.forEach((client) => {
                if (client.readyState === WebSocket.OPEN) {
                  const receiverInfo = clients.get(client);
                  if (receiverInfo && receiverInfo.projectId === senderInfo.projectId) {
                    client.send(JSON.stringify({
                      type: 'chat_message',
                      message: message.message,
                      userId: senderInfo.userId,
                      timestamp: new Date().toISOString()
                    }));
                  }
                }
              });
            }
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });
    
    ws.on('close', () => {
      clients.delete(ws);
    });
  });

  // Project routes
  app.get("/api/projects", async (req, res) => {
    try {
      const userId = 1; // Default user for now
      const projects = await storage.getProjectsByUserId(userId);
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const validatedData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(validatedData);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid project data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  app.put("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertProjectSchema.partial().parse(req.body);
      const project = await storage.updateProject(id, validatedData);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid project data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update project" });
    }
  });

  // File routes
  app.get("/api/projects/:projectId/files", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const files = await storage.getFilesByProjectId(projectId);
      res.json(files);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch files" });
    }
  });

  app.get("/api/files/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const file = await storage.getFile(id);
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      res.json(file);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch file" });
    }
  });

  app.post("/api/files", async (req, res) => {
    try {
      const validatedData = insertFileSchema.parse(req.body);
      const file = await storage.createFile(validatedData);
      res.status(201).json(file);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid file data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create file" });
    }
  });

  app.put("/api/files/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertFileSchema.partial().parse(req.body);
      const file = await storage.updateFile(id, validatedData);
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      res.json(file);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid file data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update file" });
    }
  });

  app.delete("/api/files/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteFile(id);
      if (!success) {
        return res.status(404).json({ message: "File not found" });
      }
      res.json({ message: "File deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete file" });
    }
  });

  // Chat routes
  app.get("/api/projects/:projectId/chat", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const messages = await storage.getChatMessages(projectId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const validatedData = insertChatMessageSchema.parse(req.body);
      const message = await storage.createChatMessage(validatedData);
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid message data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  // Code execution route
  app.post("/api/execute", async (req, res) => {
    try {
      const { code, language } = req.body;
      
      // Simulate code execution
      let output = "";
      let error = "";
      
      if (language === "javascript") {
        try {
          // Simple JavaScript execution simulation
          if (code.includes("console.log")) {
            const matches = code.match(/console\.log\(['"`]([^'"`]+)['"`]\)/g);
            if (matches) {
              output = matches.map((match: string) => {
                const content = match.match(/['"`]([^'"`]+)['"`]/);
                return content ? content[1] : "";
              }).join("\n");
            }
          } else {
            output = "Code executed successfully";
          }
        } catch (e) {
          error = "JavaScript execution error";
        }
      } else if (language === "python") {
        if (code.includes("print")) {
          const matches = code.match(/print\(['"`]([^'"`]+)['"`]\)/g);
          if (matches) {
            output = matches.map((match: string) => {
              const content = match.match(/['"`]([^'"`]+)['"`]/);
              return content ? content[1] : "";
            }).join("\n");
          }
        } else {
          output = "Code executed successfully";
        }
      } else {
        output = "Code executed successfully";
      }
      
      res.json({ output, error });
    } catch (error) {
      res.status(500).json({ message: "Failed to execute code" });
    }
  });

  return httpServer;
}
