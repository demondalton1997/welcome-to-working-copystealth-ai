#!/bin/bash
echo "Setting up Phantom Devbox environment..."
mkdir -p ~/Documents/Phantom_Hell_AI_Devbox/logs
touch ~/Documents/Phantom_Hell_AI_Devbox/logs/setup.log
echo "Setup complete." >> ~/Documents/Phantom_Hell_AI_Devbox/logs/setup.log
