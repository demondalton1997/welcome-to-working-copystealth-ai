# system_reporter.py
import platform
import os

def get_system_report():
    return {
        "os": platform.system(),
        "release": platform.release(),
        "cpu": platform.processor(),
        "cwd": os.getcwd()
    }
